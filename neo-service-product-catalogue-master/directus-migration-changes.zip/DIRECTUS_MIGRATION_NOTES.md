# Directus Migration Notes (Prepared)

I added:

1. `product-catalogue-service/src/main/java/com/neo/v1/service/DirectusService.java`
2. Directus config properties in:
   - `product-catalogue-service/src/main/java/com/neo/v1/reader/PropertyReader.java`
   - `product-catalogue-service/src/main/resources/application.yml`

## What you need to wire next

Your existing mappers/caching currently expect `CDAArray` from Contentful.
`DirectusService` returns `JsonNode` arrays from Directus `/items/{collection}`.

So your next step in source code is to replace calls like:

- `contentfulService.getOffers(...)`
- `contentfulService.getProducts()`
- etc.

with `directusService.*` and adapt mapper inputs (`CDAArray` -> `JsonNode`).

## Env vars to set

- `DIRECTUS_BASE_URL`
- `DIRECTUS_TOKEN`

Optional overrides:
- `DIRECTUS_COLLECTION_OFFERS`
- `DIRECTUS_COLLECTION_PRODUCTS`
- `DIRECTUS_COLLECTION_ATM`
- `DIRECTUS_COLLECTION_BRANCHES`
- `DIRECTUS_COLLECTION_OFFERS_CATEGORY`
- `DIRECTUS_COLLECTION_OFFERS_SUBPRODUCTS`
- `DIRECTUS_COLLECTION_COMPETITIONS`
- `DIRECTUS_COLLECTION_APP_BRANCHES`
- `DIRECTUS_COLLECTION_MERCHANT_CATEGORY`
- `DIRECTUS_COLLECTION_MERCHANTS`
- `DIRECTUS_COLLECTION_MERCHANT_CODE`

## Suggested migration order

1. Offers path first (service + mapper) and validate.
2. Products/ATM/Branches.
3. Competitions + AppBranches.
4. Merchants/MCC.
5. Remove Contentful SDK usage once all paths are migrated.
